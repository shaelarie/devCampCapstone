## Preparing for 1.0.0 (April 9, 2012)

## 0.3.0 (April 9, 2012)

* Refactored code
* Simplified options
* Simplified project setup

## 0.2.0 (April 7, 2012)

* fixed bug that caused frequent remeassures.
* improved documentation.


## 0.1.0 (April 6, 2012)

* initial release